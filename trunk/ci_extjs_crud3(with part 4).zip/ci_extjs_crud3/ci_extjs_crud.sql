-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 01, 2010 at 09:10 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ci_extjs_crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`) VALUES
(1, 'India'),
(2, 'Thailand');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '1',
  `occupation` varchar(150) NOT NULL,
  `birthdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `country_id`, `occupation`, `birthdate`) VALUES
(26, 'New Full Name', 'jeffbezos@amazon.com', 1, 'Occupation', '1899-10-10'),
(42, 'werwerwer', 'supe@sdjd.com', 1, 'Occupation', '1899-10-10'),
(28, 'New Full Nameprijie', 'bono@u2.co.uk', 1, 'Occupation', '1899-10-10'),
(29, 'testupdate', 'testing@gmail.com', 1, 'Occupation', '1899-10-10'),
(30, 'ewfewf', '23ew@asdf.com', 1, 'Occupation', '1899-10-10'),
(31, 'dsgdfgdfgdf', 'dfgdsfg@dfh.com', 1, 'wefwe', '0000-00-00'),
(32, '432324', '324324', 1, '324234324', '1899-11-15'),
(33, 'ewfew', 'ew', 1, 'wefewf', '2010-09-28'),
(34, 'wef', 'ewfew', 2, 'ewg', '2010-09-01'),
(35, 'wer', 'qewrwer', 1, 'wrwer', '2010-09-07'),
(36, '32423434', '324234234', 1, '23r32r32', '1899-11-14'),
(37, 'eg', 'erger', 1, '24234', '1899-11-16'),
(38, 'fgnfgn', 'fdgndfgnfgn', 1, 'rtrntrn', '1975-09-17'),
(39, 'New Full Name', 'New@sdm.com', 1, 'Occupation', '0000-00-00'),
(40, 'AAAAAAA', 'NewEmail@tfty.com', 1, 'jhvjh', '1899-11-16'),
(41, 'jgckhgcmhg', 'htdt@dt.net', 1, 'Occupation', '0000-00-00'),
(43, 'New Full Nameasdasd', 'New@Email.net', 1, 'Occupation', '0000-00-00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
